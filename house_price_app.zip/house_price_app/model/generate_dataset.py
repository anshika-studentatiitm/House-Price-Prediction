"""
Generates a synthetic but realistic housing dataset and saves it as CSV.
Run this once before train_model.py.
"""
import numpy as np
import pandas as pd

np.random.seed(42)
N = 1500

area = np.random.normal(1800, 700, N).clip(400, 6000)
bedrooms = np.random.choice([1, 2, 3, 4, 5, 6], N, p=[0.05, 0.20, 0.30, 0.25, 0.15, 0.05])
bathrooms = np.clip(bedrooms - np.random.choice([0, 1], N, p=[0.6, 0.4]), 1, 6)
floors = np.random.choice([1, 2, 3], N, p=[0.5, 0.4, 0.1])
age = np.random.randint(0, 50, N)
garage = np.random.choice([0, 1], N, p=[0.35, 0.65])
location_score = np.random.randint(1, 11, N)  # 1 = rural, 10 = prime city center

# Base price formula with some noise to simulate a realistic, learnable relationship
price = (
    area * 120
    + bedrooms * 15000
    + bathrooms * 10000
    + floors * 8000
    + garage * 12000
    + location_score * 9000
    - age * 800
    + np.random.normal(0, 20000, N)
)
price = price.clip(35000, None).round(-2)

df = pd.DataFrame({
    "area": area.round(0).astype(int),
    "bedrooms": bedrooms.astype(int),
    "bathrooms": bathrooms.astype(int),
    "floors": floors.astype(int),
    "age": age,
    "garage": garage,
    "location_score": location_score,
    "price": price.astype(int),
})

df.to_csv("model/housing_data.csv", index=False)
print("Dataset created:", df.shape)
print(df.head())
