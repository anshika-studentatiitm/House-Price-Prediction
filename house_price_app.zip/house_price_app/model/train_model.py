"""
Trains a regression model on the housing dataset, evaluates it,
generates Matplotlib visualizations, and saves the trained model
(+ scaler) to disk using pickle for use by the Flask app.
"""
import pickle
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # non-interactive backend, safe for server-side use
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

FEATURES = ["area", "bedrooms", "bathrooms", "floors", "age", "garage", "location_score"]
TARGET = "price"

# ---------------------------------------------------------------
# 1. Load & clean data
# ---------------------------------------------------------------
df = pd.read_csv("model/housing_data.csv")
df = df.dropna()
df = df[(df["area"] > 0) & (df["price"] > 0)]  # basic sanity cleaning

X = df[FEATURES]
y = df[TARGET]

# ---------------------------------------------------------------
# 2. Feature scaling (helps linear model & keeps inputs consistent)
# ---------------------------------------------------------------
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

# ---------------------------------------------------------------
# 3. Train models & evaluate (compare Linear Regression vs Random Forest)
# ---------------------------------------------------------------
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(n_estimators=200, max_depth=8, random_state=42),
}

results = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    rmse = np.sqrt(mean_squared_error(y_test, preds))
    r2 = r2_score(y_test, preds)
    results[name] = {"model": model, "mae": mae, "rmse": rmse, "r2": r2}
    print(f"\n{name}")
    print(f"  MAE  : {mae:,.2f}")
    print(f"  RMSE : {rmse:,.2f}")
    print(f"  R2   : {r2:.4f}")

# Pick the best model by R2
best_name = max(results, key=lambda k: results[k]["r2"])
best_model = results[best_name]["model"]
print(f"\nSelected best model: {best_name} (R2={results[best_name]['r2']:.4f})")

# ---------------------------------------------------------------
# 4. Save model + scaler + metrics for the Flask app
# ---------------------------------------------------------------
with open("model/house_price_model.pkl", "wb") as f:
    pickle.dump({
        "model": best_model,
        "scaler": scaler,
        "features": FEATURES,
        "model_name": best_name,
        "metrics": {k: {"mae": v["mae"], "rmse": v["rmse"], "r2": v["r2"]} for k, v in results.items()},
    }, f)

print("\nModel saved to model/house_price_model.pkl")

# ---------------------------------------------------------------
# 5. Visualizations (Matplotlib) -> saved into static/images for the app
# ---------------------------------------------------------------
plt.style.use("seaborn-v0_8-whitegrid") if "seaborn-v0_8-whitegrid" in plt.style.available else None

# 5a. Area vs Price scatter
plt.figure(figsize=(7, 5))
plt.scatter(df["area"], df["price"], alpha=0.4, c="#2563eb", edgecolors="none")
plt.title("Area vs Price")
plt.xlabel("Area (sq.ft)")
plt.ylabel("Price")
plt.tight_layout()
plt.savefig("static/images/area_vs_price.png", dpi=120)
plt.close()

# 5b. Bedrooms vs average price (bar chart)
avg_by_bed = df.groupby("bedrooms")["price"].mean()
plt.figure(figsize=(7, 5))
plt.bar(avg_by_bed.index.astype(str), avg_by_bed.values, color="#16a34a")
plt.title("Average Price by Number of Bedrooms")
plt.xlabel("Bedrooms")
plt.ylabel("Average Price")
plt.tight_layout()
plt.savefig("static/images/bedrooms_vs_price.png", dpi=120)
plt.close()

# 5c. Correlation heatmap
plt.figure(figsize=(7, 6))
corr = df[FEATURES + [TARGET]].corr()
im = plt.imshow(corr, cmap="coolwarm", vmin=-1, vmax=1)
plt.colorbar(im, fraction=0.046, pad=0.04)
plt.xticks(range(len(corr.columns)), corr.columns, rotation=45, ha="right")
plt.yticks(range(len(corr.columns)), corr.columns)
for i in range(len(corr.columns)):
    for j in range(len(corr.columns)):
        plt.text(j, i, f"{corr.iloc[i, j]:.2f}", ha="center", va="center", fontsize=7)
plt.title("Feature Correlation Heatmap")
plt.tight_layout()
plt.savefig("static/images/correlation_heatmap.png", dpi=120)
plt.close()

# 5d. Actual vs Predicted (best model on test set)
best_preds = best_model.predict(X_test)
plt.figure(figsize=(7, 5))
plt.scatter(y_test, best_preds, alpha=0.4, c="#9333ea", edgecolors="none")
lims = [min(y_test.min(), best_preds.min()), max(y_test.max(), best_preds.max())]
plt.plot(lims, lims, "r--", linewidth=1.5, label="Ideal fit")
plt.title(f"Actual vs Predicted Price ({best_name})")
plt.xlabel("Actual Price")
plt.ylabel("Predicted Price")
plt.legend()
plt.tight_layout()
plt.savefig("static/images/actual_vs_predicted.png", dpi=120)
plt.close()

print("Visualizations saved to static/images/")
