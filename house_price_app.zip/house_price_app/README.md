# House Price Prediction System

A web-based machine learning application built with **Python, Flask, and Scikit-learn**
that estimates house prices from property features such as area, bedrooms, bathrooms,
floors, age, garage, and location quality.

## Features

- **User authentication** — Register / Login / Logout (passwords hashed with Werkzeug)
- **User Dashboard** — quick stats, recent predictions, shortcuts to key actions
- **Prediction Page** — enter property features, get an instant ML-generated price estimate
- **History Page** — every prediction is saved per-user in SQLite and can be reviewed or deleted
- **Insights Page** — Matplotlib visualizations (area vs price, bedrooms vs price,
  correlation heatmap, actual vs predicted) plus model evaluation metrics (MAE, RMSE, R²)
- No admin module — every feature is scoped to the logged-in end user

## Tech Stack

| Layer            | Technology                          |
|-------------------|--------------------------------------|
| Backend           | Flask, Flask-SQLAlchemy              |
| ML / Data         | Scikit-learn, Pandas, NumPy          |
| Visualization     | Matplotlib                           |
| Database          | SQLite                               |
| Templating        | Jinja2                               |
| Frontend          | HTML, CSS (no JS framework required) |

## Project Structure

```
house_price_app/
├── app.py                     # Flask application (routes, auth, DB models)
├── model/
│   ├── generate_dataset.py    # Generates synthetic training data (run first, optional)
│   ├── train_model.py         # Cleans data, trains & evaluates models, saves visualizations
│   ├── housing_data.csv       # Training dataset
│   └── house_price_model.pkl  # Trained model + scaler (loaded by app.py)
├── templates/                 # Jinja2 templates
│   ├── base.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── predict.html
│   ├── history.html
│   └── insights.html
├── static/
│   ├── css/style.css
│   └── images/                # Matplotlib chart outputs
└── instance/
    └── app.db                 # SQLite database (created on first run)
```

## Setup & Run

1. **Install dependencies**
   ```bash
   pip install flask flask-sqlalchemy scikit-learn pandas numpy matplotlib werkzeug
   ```

2. **(Optional) Regenerate the dataset and retrain the model**
   ```bash
   cd model
   python generate_dataset.py
   python train_model.py
   cd ..
   ```
   This is already done — `house_price_model.pkl` and the chart images are included.

3. **Run the app**
   ```bash
   python app.py
   ```
   The app initializes the SQLite database automatically on first run.

4. **Open in browser**
   ```
   http://127.0.0.1:5000
   ```

## How the ML Pipeline Works

1. **Data**: A synthetic dataset of 1,500 houses with realistic relationships between
   area, bedrooms, bathrooms, floors, age, garage, location score, and price.
2. **Preprocessing**: Missing values and invalid rows dropped; features scaled with
   `StandardScaler` for consistent input ranges.
3. **Training**: Both `LinearRegression` and `RandomForestRegressor` are trained;
   the better-performing model (by R²) is selected and saved.
4. **Evaluation**: MAE, RMSE, and R² are computed on a held-out 20% test split and
   shown on the Insights page.
5. **Inference**: When a user submits the Prediction form, inputs are scaled with the
   same fitted `StandardScaler` and passed to the saved model to produce an estimate,
   which is then stored in the user's history.

## Notes

- Default `SECRET_KEY` and debug mode are set for local development — change these
  before any production deployment.
- To reset all data, delete `instance/app.db` and restart the app.
