"""
House Price Prediction System
Flask + Scikit-learn + SQLite

Run with: python app.py
"""
import os
import pickle
from datetime import datetime

import pandas as pd
from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config["SECRET_KEY"] = "dev-secret-key-change-in-production"
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'app.db')}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

# ---------------------------------------------------------------
# Load trained ML model (model + scaler bundled together)
# ---------------------------------------------------------------
MODEL_PATH = os.path.join(BASE_DIR, "model", "house_price_model.pkl")
with open(MODEL_PATH, "rb") as f:
    bundle = pickle.load(f)

ML_MODEL = bundle["model"]
SCALER = bundle["scaler"]
FEATURES = bundle["features"]
MODEL_NAME = bundle["model_name"]
METRICS = bundle["metrics"]


# ---------------------------------------------------------------
# Database Models
# ---------------------------------------------------------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    predictions = db.relationship("Prediction", backref="user", cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)

    area = db.Column(db.Float, nullable=False)
    bedrooms = db.Column(db.Integer, nullable=False)
    bathrooms = db.Column(db.Integer, nullable=False)
    floors = db.Column(db.Integer, nullable=False)
    age = db.Column(db.Integer, nullable=False)
    garage = db.Column(db.Integer, nullable=False)
    location_score = db.Column(db.Integer, nullable=False)

    predicted_price = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ---------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------
def login_required(view_func):
    from functools import wraps

    @wraps(view_func)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view_func(*args, **kwargs)

    return wrapper


def current_user():
    uid = session.get("user_id")
    if uid:
        return User.query.get(uid)
    return None


@app.context_processor
def inject_user():
    return {"current_user": current_user()}


# ---------------------------------------------------------------
# Routes: Auth
# ---------------------------------------------------------------
@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not name or not email or not password:
            flash("All fields are required.", "danger")
            return redirect(url_for("register"))

        if password != confirm:
            flash("Passwords do not match.", "danger")
            return redirect(url_for("register"))

        if len(password) < 6:
            flash("Password must be at least 6 characters.", "danger")
            return redirect(url_for("register"))

        if User.query.filter_by(email=email).first():
            flash("An account with this email already exists.", "danger")
            return redirect(url_for("register"))

        user = User(name=name, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        flash("Account created successfully! Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            session["user_id"] = user.id
            session["user_name"] = user.name
            flash(f"Welcome back, {user.name}!", "success")
            return redirect(url_for("dashboard"))

        flash("Invalid email or password.", "danger")
        return redirect(url_for("login"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


# ---------------------------------------------------------------
# Routes: Dashboard
# ---------------------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    recent = (
        Prediction.query.filter_by(user_id=user.id)
        .order_by(Prediction.created_at.desc())
        .limit(5)
        .all()
    )
    total_predictions = Prediction.query.filter_by(user_id=user.id).count()
    avg_price = db.session.query(db.func.avg(Prediction.predicted_price)).filter_by(user_id=user.id).scalar()

    return render_template(
        "dashboard.html",
        recent=recent,
        total_predictions=total_predictions,
        avg_price=avg_price,
        model_name=MODEL_NAME,
        r2=METRICS[MODEL_NAME]["r2"],
    )


# ---------------------------------------------------------------
# Routes: Prediction
# ---------------------------------------------------------------
@app.route("/predict", methods=["GET", "POST"])
@login_required
def predict():
    result = None

    if request.method == "POST":
        try:
            area = float(request.form.get("area"))
            bedrooms = int(request.form.get("bedrooms"))
            bathrooms = int(request.form.get("bathrooms"))
            floors = int(request.form.get("floors"))
            age = int(request.form.get("age"))
            garage = 1 if request.form.get("garage") == "yes" else 0
            location_score = int(request.form.get("location_score"))

            if area <= 0:
                flash("Area must be greater than 0.", "danger")
                return redirect(url_for("predict"))

            # Preprocess input the same way training data was scaled
            input_df = pd.DataFrame(
                [[area, bedrooms, bathrooms, floors, age, garage, location_score]],
                columns=FEATURES,
            )
            input_scaled = SCALER.transform(input_df)
            predicted_price = float(ML_MODEL.predict(input_scaled)[0])
            predicted_price = max(predicted_price, 0)

            # Save to history
            record = Prediction(
                user_id=session["user_id"],
                area=area,
                bedrooms=bedrooms,
                bathrooms=bathrooms,
                floors=floors,
                age=age,
                garage=garage,
                location_score=location_score,
                predicted_price=predicted_price,
            )
            db.session.add(record)
            db.session.commit()

            result = {
                "price": predicted_price,
                "area": area,
                "bedrooms": bedrooms,
                "bathrooms": bathrooms,
                "floors": floors,
                "age": age,
                "garage": "Yes" if garage else "No",
                "location_score": location_score,
            }
            flash("Prediction generated and saved to your history.", "success")

        except (TypeError, ValueError):
            flash("Please enter valid numeric values for all fields.", "danger")
            return redirect(url_for("predict"))

    return render_template("predict.html", result=result, model_name=MODEL_NAME)


# ---------------------------------------------------------------
# Routes: History
# ---------------------------------------------------------------
@app.route("/history")
@login_required
def history():
    user = current_user()
    records = (
        Prediction.query.filter_by(user_id=user.id)
        .order_by(Prediction.created_at.desc())
        .all()
    )
    return render_template("history.html", records=records)


@app.route("/history/delete/<int:prediction_id>", methods=["POST"])
@login_required
def delete_history(prediction_id):
    record = Prediction.query.get_or_404(prediction_id)
    if record.user_id != session["user_id"]:
        flash("You are not authorized to delete this record.", "danger")
        return redirect(url_for("history"))

    db.session.delete(record)
    db.session.commit()
    flash("Prediction record deleted.", "info")
    return redirect(url_for("history"))


# ---------------------------------------------------------------
# Routes: Insights (Matplotlib visualizations)
# ---------------------------------------------------------------
@app.route("/insights")
@login_required
def insights():
    return render_template("insights.html", metrics=METRICS, model_name=MODEL_NAME)


# ---------------------------------------------------------------
# App entry point
# ---------------------------------------------------------------
def init_db():
    os.makedirs(os.path.join(BASE_DIR, "instance"), exist_ok=True)
    with app.app_context():
        db.create_all()


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
